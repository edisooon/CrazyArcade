﻿
using var game = new CrazyArcade.CAGame();
game.Run();


﻿using System;
namespace CrazyArcade.CAFrameWork.CAGame
{
	public interface IGameDelegate
	{
		
	}
}


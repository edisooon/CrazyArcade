﻿using System;
namespace CrazyArcade.CAFramework
{
    public enum Dir
    {
        Up = 0,
        Down = 2,
        Left = 1,
        Right = 3,
        right = 4
    }
}

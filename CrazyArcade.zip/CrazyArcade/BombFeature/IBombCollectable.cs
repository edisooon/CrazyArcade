﻿using System;
namespace CrazyArcade.BombFeature
{
	public interface IBombCollectable
	{
		void recollectBomb();
	}
}


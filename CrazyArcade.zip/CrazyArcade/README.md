﻿### Framework UML
![FrameworkUML](./UML_CAFramework.png)